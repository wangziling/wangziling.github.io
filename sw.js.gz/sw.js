importScripts('./assets/workbox/workbox-sw.js');
workbox.setConfig({
  modulePathPrefix: './assets/workbox/',
});